# Security Policy

## Supported Versions
| Version | Supported          |
| ------- | ------------------ |
| >= 0.9   | :white_check_mark: |
| < 0.9.X   | :x:                |

## Reporting a Vulnerability

If you found a security vulnerability create a new security [advisory](https://github.com/Paymenter/Paymenter/security/advisories/new) OR send an email to corwin@paymenter.org