<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\SettingsProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    \SocialiteProviders\Manager\ServiceProvider::class,
];
