<?php

namespace Paymenter\Extensions\Others\Affiliates\Admin\Resources\AffiliateResource\Pages;

use Filament\Resources\Pages\CreateRecord;
use Paymenter\Extensions\Others\Affiliates\Admin\Resources\AffiliateResource;

class CreateAffiliate extends CreateRecord
{
    protected static string $resource = AffiliateResource::class;
}
