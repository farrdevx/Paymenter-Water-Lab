<?php

return [
    'affiliate' => 'Affiliate',
    'signup-for-affiliate' => 'Signup for Affiliate',
    'code' => 'Code',
    'visitors' => 'Visitors',
    'total-visitors' => 'Total Visitors',
    'signups' => 'Signups',
    'total-signups' => 'Total Signups',
    'earnings' => 'Earnings',
    'total-earnings' => 'Total Earnings',
    'your-affiliate-link' => 'Your affiliate link',
    'copy' => 'Copy',

    'you-havent-signed-up-yet' => 'You have not signed up for affiliates program yet!',
    'you-are-already-affiliated' => 'You have already signed up for affiliate program.',
    'signup-success' => 'Successfully signed up for affiliate program!',
];
