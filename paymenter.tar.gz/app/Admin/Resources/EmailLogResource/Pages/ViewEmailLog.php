<?php

namespace App\Admin\Resources\EmailLogResource\Pages;

use App\Admin\Resources\EmailLogResource;
use Filament\Resources\Pages\ViewRecord;

class ViewEmailLog extends ViewRecord
{
    protected static string $resource = EmailLogResource::class;
}
