<?php

namespace App\Classes\Extension;

/**
 * Class Gateway
 */
class Gateway extends Extension {}
