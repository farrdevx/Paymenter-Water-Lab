<aside class="fixed top-0 left-0 z-10 flex-col justify-between hidden w-64 h-screen mt-14 md:flex border-e border-neutral bg-background-secondary rtl:right-0">
    <x-navigation.sidebar-links />
</aside>
